package sarankar.plugin.sms_sender

import android.Manifest
import android.app.Activity
import android.app.PendingIntent
import android.app.role.RoleManager
import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.IntentSender
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.provider.Telephony
import android.telephony.SmsManager
import android.telephony.TelephonyManager
import android.util.Log
import android.widget.Toast
import androidx.annotation.NonNull
import androidx.annotation.Nullable
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import io.flutter.embedding.android.FlutterActivityLaunchConfigs
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.embedding.engine.plugins.activity.ActivityAware
import io.flutter.embedding.engine.plugins.activity.ActivityPluginBinding
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.MethodChannel.MethodCallHandler
import io.flutter.plugin.common.MethodChannel.Result
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch


/** SmsSenderPlugin */
class SmsSenderPlugin : FlutterPlugin, MethodCallHandler, ActivityAware {

    private lateinit var context: Context
    private lateinit var channel: MethodChannel
    private var activity: Activity? = null

    private lateinit var sentReceiver: BroadcastReceiver
    private lateinit var deliveredReceiver: BroadcastReceiver

    override fun onAttachedToEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        context = binding.applicationContext
        channel = MethodChannel(binding.binaryMessenger, "sms_sender")
        channel.setMethodCallHandler(this)
    }

    override fun onAttachedToActivity(binding: ActivityPluginBinding) {
        activity = binding.activity
    }

    override fun onDetachedFromActivityForConfigChanges() {
        activity = null
    }

    override fun onReattachedToActivityForConfigChanges(binding: ActivityPluginBinding) {
        activity = binding.activity
    }

    override fun onDetachedFromActivity() {
        activity = null
    }

    override fun onMethodCall(call: MethodCall, result: Result) {
        when (call.method) {
            "sendSms" -> {
                val message = call.argument<String>("message")
                val recipients = call.argument<List<String>>("recipients")
                val deleteAfterSent = call.argument<Boolean>("deleteAfterSent") ?: false
                val smsId = call.argument<Int>("smsId") ?: 0
                sendSms(message, recipients, smsId, deleteAfterSent, result)
            }

            "isDefaultSmsApp" -> {
                result.success(isDefaultSmsApp(context))
            }

            "setAsDefaultSmsApp" -> {
                result.success(setAsDefaultSmsApp(activity))
            }

            else -> result.notImplemented()
        }
    }

    private fun sendSms(
        message: String?,
        recipients: List<String>?,
        smsId: Int,
        deleteAfterSent: Boolean,
        result: Result
    ) {
        val smsManager = SmsManager.getDefault()

        // Create pending intents for sent and delivered events

        val smsSentIntent = Intent("SMS_SENT")
        smsSentIntent.putExtra("smsId", smsId)

        val sentIntent = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            PendingIntent.getBroadcast(context, smsId, smsSentIntent, PendingIntent.FLAG_MUTABLE)
        } else {
            PendingIntent.getBroadcast(context, smsId, smsSentIntent, 0)
        }

        val smsdeliveredIntent = Intent("SMS_DELIVERED")
        smsdeliveredIntent.putExtra("smsId", smsId)

        val deliveredIntent = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            PendingIntent.getBroadcast(context, smsId, smsdeliveredIntent, PendingIntent.FLAG_MUTABLE)
        } else {
            PendingIntent.getBroadcast(context, smsId, smsdeliveredIntent, 0)
        }

        // Create broadcast receivers for sent and delivered events
        sentReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val resultCode = resultCode
                val id = intent?.getIntExtra("smsId", -1)
                if (intent != null && id == smsId) {

                    val success = resultCode == Activity.RESULT_OK
                    Log.d(
                        "SmsSenderPlugin",
                        "SMS sent $smsId INTENT SMS ID: $id , Is Success ? : ${success}"
                    )
                    channel.invokeMethod(
                        "onSmsSent",
                        "{\"success\": $success, \"smsId\": ${id}}"
                    );

//                    context?.unregisterReceiver(sentReceiver)
                }
            }
        }
        deliveredReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val resultCode = resultCode
                val success = resultCode == Activity.RESULT_OK
                val id = intent?.getIntExtra("smsId", -1)

                if (intent != null && smsId == id) {

                    Log.d(
                        "SmsSenderPlugin",
                        "SMS ID: $smsId is delivered  Intent ID: $id , Is Success ? : ${success}"
                    )
                    channel.invokeMethod("onSmsDelivered", success)
                    channel.invokeMethod(
                        "onSmsDelivered",
                        "{\"success\": $success, \"smsId\": ${id}}"
                    );

                    Log.d("SmsSenderPlugin", "SMS deleted $deleteAfterSent $success")
                    if (deleteAfterSent && success) {
                        deleteLastSentSms()
                    }

//                    context?.unregisterReceiver(deliveredReceiver)
                }
            }
        }

        // Register broadcast receivers for sent and delivered events
        context.registerReceiver(sentReceiver, IntentFilter("SMS_SENT"))
        context.registerReceiver(deliveredReceiver, IntentFilter("SMS_DELIVERED"))

        // Send the SMS message to the specified phone numbers
        for (recipient in recipients ?: emptyList()) {
            smsManager.sendTextMessage(
                recipient,
                null,
                message,
                sentIntent,
                deliveredIntent
            ); // deliveredIntent
        }

        result.success(true)
    }

    fun isDefaultSmsApp(context: Context): Boolean {
        return context.packageName == Telephony.Sms.getDefaultSmsPackage(context)
    }

    private fun deleteLastSentSms(): Boolean {
        val uriSmsSent = Uri.parse("content://sms/sent")
        val cursor =
            context.contentResolver.query(uriSmsSent, null, null, null, "date DESC LIMIT 1")
        if (cursor != null && cursor.moveToFirst()) {
            val messageId = cursor.getString(cursor.getColumnIndex("_id"))
            val deleteUri = Uri.parse("content://sms/" + messageId)
            context.contentResolver.delete(deleteUri, null, null)
        }
        cursor?.close()
        Log.d("SmsSenderPlugin", "Last SMS deleted")
        channel.invokeMethod("onLastSmsDeleted", true)
        return true
    }

    fun setAsDefaultSmsApp(activity: Activity?): Boolean {
        if (activity == null) {
            return false
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // For Android 11 and later, use RoleManager to set the default SMS app
            val roleManager = activity.getSystemService(RoleManager::class.java)
            if (roleManager.isRoleAvailable(RoleManager.ROLE_SMS)) {
                if (!roleManager.isRoleHeld(RoleManager.ROLE_SMS)) {
                    val intent = roleManager.createRequestRoleIntent(RoleManager.ROLE_SMS)
                    activity.startActivityForResult(intent, 0)
                }
            }
        } else {
            // For earlier Android versions, use Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT to set the default SMS app
            val intent = Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
                .putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, activity.packageName)
            try {
                activity.startActivity(intent)
            } catch (e: ActivityNotFoundException) {
                // Handle the case where the user doesn't have the appropriate settings activity
                e.printStackTrace()
            }
        }
        return true
    }


    override fun onDetachedFromEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        channel.setMethodCallHandler(null)
    }
}

