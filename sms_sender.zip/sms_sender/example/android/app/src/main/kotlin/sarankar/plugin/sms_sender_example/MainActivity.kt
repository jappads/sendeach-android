package sarankar.plugin.sms_sender_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
