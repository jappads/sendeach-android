//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<sms_sender/SmsSenderPlugin.h>)
#import <sms_sender/SmsSenderPlugin.h>
#else
@import sms_sender;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [SmsSenderPlugin registerWithRegistrar:[registry registrarForPlugin:@"SmsSenderPlugin"]];
}

@end
